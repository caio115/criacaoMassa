package com.accenture;

import javax.sql.DataSource;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Controller;

@SpringBootApplication
@Controller
public class Configuracao {

	/**@ResponseBody
	@RequestMapping("/")
	String ola(){
		return "teste- acesso";
	}
	*/
	
	public static void main(String[] args) {
		SpringApplication.run(Configuracao.class, args);
	}
	
	@Bean
	public DataSource dataSource(){
	    DriverManagerDataSource dataSource = new DriverManagerDataSource();
	    dataSource.setDriverClassName("com.mysql.jdbc.Driver");
	    dataSource.setUrl("jdbc:mysql://127.0.0.1:3306/geracaoMassa?useTimezone=true&serverTimezone=UTC");
	    dataSource.setUsername("root");
	    dataSource.setPassword("1234");
	    return dataSource;
	}
	
}
