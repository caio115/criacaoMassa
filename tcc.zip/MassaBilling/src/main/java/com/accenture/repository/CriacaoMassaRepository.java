package com.accenture.repository;

import org.springframework.data.repository.CrudRepository;

import com.accenture.model.Template;

public interface CriacaoMassaRepository extends CrudRepository<Template, Integer>{

}
