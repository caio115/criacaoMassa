package com.accenture.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;

import com.accenture.model.SI;
import com.accenture.model.Template;
import com.accenture.repository.CriacaoMassaRepository;


@Controller
public class ConvidadoController {
	
	@Autowired
	private CriacaoMassaRepository repository;
	
	
	@RequestMapping("/")
	public String index(){
		return "index";
	}
	
	@RequestMapping("/criarConta")
	public String criacaoConta(final Template template){
		return "criacaoconta";
	}
	
	@RequestMapping("/listaTemplate")
	public String listaTemplate(Model model){
		Iterable<Template> templates = repository.findAll();
		model.addAttribute("listaTemplates", templates);
		
		
		return "listaTemplate";
	}
	
	@RequestMapping(value="/criacaoconta", params={"addRowSI"})
    public String addRow(final Template template, final BindingResult bindingResult) {
		template.getIdConta().getSIs().add(new SI());
		
        return "criacaoconta";
    }
	
	@RequestMapping(value="/criacaoconta", params={"save"})
    public String saveSeedstarter(final Template seedStarter, final BindingResult bindingResult, final ModelMap model) {
        if (bindingResult.hasErrors()) {
            return "criacaoconta";
        }
        repository.save(seedStarter);
        
        Iterable<Template> templates = repository.findAll();
		model.addAttribute("listaTemplates", templates);
        
		return "listaTemplate";
    }
	
}
