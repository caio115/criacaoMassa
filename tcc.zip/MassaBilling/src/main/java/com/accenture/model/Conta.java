package com.accenture.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity(name = "ACCOUNT")
public class Conta {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Integer id;
	
	@Column(name="faturaID")
	private Integer faturaID;
	
	@Column(name="categoria")
	private Integer categoria;
	
	@Column(name="VipCode")
	private Integer vipCode;
	
	@Column(name="MessageGroup")
	private Integer messageGroup;
	
	@Column(name="ServiceCenter")
	private Integer serviceCenter;
	
	@Column(name="TaxExempt")
	private String taxExempt;
	
	@Column(name="BillPeriod")
	private String billPeriod;
	
	@Column(name="BillFormat")
	private Integer billFormat;
	
	@Column(name="marketCode")
	private Integer marketCode;
	
	@Column(name="RateClass")
	private Integer rateClass;
    
	@Column(name="PaymentMethod")
	private Integer paymentMethod;
                                  
	@Column(name="NomeSite", length=55)
	private String nomeSite;
	
	@Column(name="CidadeCliente", length=60)
	private String cidadeCliente;
	
	@Column(name="EstadoCliente", length=60)
	private String estadoCliente;
	 
	@Column(name="CEPCliente", length=12)
	private String CEPCliente;
	
	@Column(name="EnderecoPagamento", length=60)
	private String enderecoPagamento;
	
	@Column(name="CidadePagamento", length=60)
	private String cidadePagamento;

	@Column(name="EstadoPagamento", length=60)
	private String estadoPagamento;
	 
	@Column(name="CEPPagamento", length=12)
	private String CEPPagamento;
	
	@OneToMany(cascade = {CascadeType.ALL})
	@JoinColumn(name = "SI")
    private List<SI> SIs;
	
	/**
	 * Getters and Setters
	 * @return
	 */
	
	public Integer getFaturaID() {
		return faturaID;
	}
	public void setFaturaID(Integer faturaID) {
		this.faturaID = faturaID;
	}
	public Integer getCategoria() {
		return categoria;
	}
	public void setCategoria(Integer categoria) {
		this.categoria = categoria;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getVipCode() {
		return vipCode;
	}
	public void setVipCode(Integer vipCode) {
		this.vipCode = vipCode;
	}
	public Integer getMessageGroup() {
		return messageGroup;
	}
	public void setMessageGroup(Integer MessageGroup) {
		messageGroup = MessageGroup;
	}
	public Integer getServiceCenter() {
		return serviceCenter;
	}
	public void setServiceCenter(Integer serviceCenter) {
		this.serviceCenter = serviceCenter;
	}
	public String getTaxExempt() {
		return taxExempt;
	}
	public void setTaxExempt(String taxExempt) {
		this.taxExempt = taxExempt;
	}
	public String getBillPeriod() {
		return billPeriod;
	}
	public void setBillPeriod(String billPeriod) {
		this.billPeriod = billPeriod;
	}
	public Integer getBillFormat() {
		return billFormat;
	}
	public void setBillFormat(Integer billFormat) {
		this.billFormat = billFormat;
	}
	public Integer getMarketCode() {
		return marketCode;
	}
	public void setMarketCode(Integer marketCode) {
		this.marketCode = marketCode;
	}
	public Integer getRateClass() {
		return rateClass;
	}
	public void setRateClass(Integer rateClass) {
		this.rateClass = rateClass;
	}
	public Integer getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(Integer paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	public String getNomeSite() {
		return nomeSite;
	}
	public void setNomeSite(String nomeSite) {
		this.nomeSite = nomeSite;
	}
	public String getCidadeCliente() {
		return cidadeCliente;
	}
	public void setCidadeCliente(String cidadeCliente) {
		this.cidadeCliente = cidadeCliente;
	}
	public String getEstadoCliente() {
		return estadoCliente;
	}
	public void setEstadoCliente(String estadoCliente) {
		this.estadoCliente = estadoCliente;
	}
	public String getCEPCliente() {
		return CEPCliente;
	}
	public void setCEPCliente(String cEPCliente) {
		CEPCliente = cEPCliente;
	}
	public String getEnderecoPagamento() {
		return enderecoPagamento;
	}
	public void setEnderecoPagamento(String enderecoPagamento) {
		this.enderecoPagamento = enderecoPagamento;
	}
	public String getCidadePagamento() {
		return cidadePagamento;
	}
	public void setCidadePagamento(String cidadePagamento) {
		this.cidadePagamento = cidadePagamento;
	}
	public String getEstadoPagamento() {
		return estadoPagamento;
	}
	public void setEstadoPagamento(String estadoPagamento) {
		this.estadoPagamento = estadoPagamento;
	}
	public String getCEPPagamento() {
		return CEPPagamento;
	}
	public void setCEPPagamento(String cEPPagamento) {
		CEPPagamento = cEPPagamento;
	}
	public List<SI> getSIs() {
		return SIs;
	}
	public void setSIs(List<SI> sIs) {
		SIs = sIs;
	}

		
	
}
