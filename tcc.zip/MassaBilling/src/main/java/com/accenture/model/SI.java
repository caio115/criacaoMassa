package com.accenture.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class SI {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="idSI")
	private Integer idSI;
	
	@Column(name="FaturaId")
	private String faturaID;
	
	@Column(name="SIfaturaID")
	private String SIFaturaID;

	public String getFaturaID() {
		return faturaID;
	}

	public void setFaturaID(String faturaID) {
		this.faturaID = faturaID;
	}

	public String getSIFaturaID() {
		return SIFaturaID;
	}

	public void setSIFaturaID(String sIFaturaID) {
		SIFaturaID = sIFaturaID;
	}

	public Integer getIdSI() {
		return idSI;
	}

	public void setIdSI(Integer idSI) {
		this.idSI = idSI;
	}

	
	
	
	

}
