package com.accenture.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity(name = "template")
public class Template {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="idtemplate")
	private Integer idTemplate;
	
	@OneToOne(cascade = {CascadeType.ALL})
	@JoinColumn(name = "idconta")
	private Conta idConta;
	
	@Column(name="tipotemplate")
	private String tipoTemplate;
	
	@Column(name="descricao")
	private String descricao;
	
	@Column(name="owner")
	private String owner;
	
	
	public Integer getIdTemplate() {
		return idTemplate;
	}
	public void setIdTemplate(Integer idTemplate) {
		this.idTemplate = idTemplate;
	}

	public Conta getIdConta() {
		return idConta;
	}
	public void setIdConta(Conta idConta) {
		this.idConta = idConta;
	}
	public String getTipoTemplate() {
		return tipoTemplate;
	}
	public void setTipoTemplate(String tipoTemplate) {
		this.tipoTemplate = tipoTemplate;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}

	
}
